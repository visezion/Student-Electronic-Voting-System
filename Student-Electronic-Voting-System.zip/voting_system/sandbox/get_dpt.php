<?php
//Include database connection
require("../config/db.php");
?>
<html>


<?php
$org = trim($_POST['faculty']);
$sql = "SELECT * FROM department WHERE faculty = ?";
if(!$stmt = $db->prepare($sql)) {
    echo $stmt->error;
} else {
    $stmt->bind_param("s", $org);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<option value="">*****Select Position*****</option>
<?php if($result) { ?>
    <?php while($rowDpt = $result->fetch_assoc()) { ?>
        <option value="<?php echo $rowDpt['department_name']; ?>"><?php echo $rowDpt['department_name']; ?></option>
    <?php } //End while ?>
<?php } //End if ?>

</html>