<?php 


//Include authentication
require("process/auth.php");

//Include database connection
require("../config/db.php");

//Include class Organization
require("classes/Organization.php");

//Include class Position
require("classes/Position.php");

//Include class Nominees
require("classes/Nominees.php");





/*echo $row["$org"];

$totlcount+=$totalunit;
$cnt++;
     echo ($cnt-1);                                   
*/

$qry = "SELECT COUNT(org)  AS count 
        FROM votes WHERE id=15" ;

$res = $db->query($qry);

$total = 0;
$rec = $row = $res->fetch_assoc();
$total = $rec['count'];

echo "Total: " . $total . "\n";



?>



