<?php
//require("process/auth.php");

//Include database connection
//require("../config/db.php");

//require("classes/faculty.php");
class add_faculty
{
    public function INSERT_ORG($organization2) {
        global $db;


 //Check if the organization already exists in the database
        $sql = "SELECT *
                FROM organization
                WHERE org = ?
                LIMIT 1";
        if(!$stmt = $db->prepare($sql)) {
            echo $stmt->error;
        } else {
            $stmt->bind_param("s", $organization2);
            $stmt->execute();
            $result = $stmt->get_result();
        }

        if($result->num_rows > 0) {

            echo "<div class='alert alert-danger'>Sorry the organization you are trying to insert already exists in the database.</div>";
        } else {


//Successfully inserted

        $sql = "INSERT INTO organization (org) VALUES (?) ";


        if(!$stmt = $db->prepare($sql)) {
                    echo $stmt->error;
                } else {
                    $stmt->bind_param("s", $organization2);
                }

                if($stmt->execute()) {
                echo "<div class='alert alert-success'>Organization was inserted successfully.</div>";
                }
                
                $stmt->free_result();
                return $stmt;
            }
        }
    }
