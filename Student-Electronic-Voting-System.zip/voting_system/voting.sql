-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2018 at 05:38 PM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `name`) VALUES
(1, 'admin', 'admin', 'Modupeola Temiloluwa');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `faculty` varchar(222) NOT NULL,
  `department_name` varchar(222) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `faculty`, `department_name`) VALUES
(1, 'Faculty of Basic Medical Sciences', 'Medical Microbiology and Pathology'),
(2, 'Faculty of Basic Medical Sciences', 'Physiology'),
(3, 'Faculty of Basic Medical Sciences', 'Nursing'),
(4, 'Faculty of Basic Medical Sciences', 'Bio-Chemistry'),
(5, 'Faculty of Basic Medical Sciences', 'Medical Science Laboratory'),
(6, 'Faculty of Basic Medical Sciences', 'Morbid Anatomy / Histo-pathology'),
(7, 'Faculty of Basic Medical Sciences', 'Haematology and Blood Transfusion                    '),
(8, 'Faculty of Basic Medical Sciences', 'Chemical Pathology'),
(9, 'Faculty of Clinical Sciences', 'Medicine'),
(10, 'Faculty of Clinical Sciences', 'Surgery'),
(11, 'Faculty of Clinical Sciences', 'Radiology'),
(12, 'Faculty of Clinical Sciences', 'Paediatrics'),
(13, 'Faculty of Clinical Sciences', 'Obstetrics'),
(14, 'Faculty of Clinical Sciences', 'Ophthalmologya'),
(15, 'Faculty of Clinical Sciences', 'Psychiatry\n'),
(16, 'Faculty of Clinical Sciences', 'Oto-Rhino Zarincology\n'),
(17, 'Faculty of Clinical Sciences', 'Anaesthesia'),
(18, 'Faculty of Agricultural Sciences', 'Agricultural Economics'),
(19, 'Faculty of Agricultural Sciences', 'Agricultural Extension and Rural Development'),
(20, 'Faculty of Agricultural Sciences', 'Crop Production and Soil Science\n'),
(21, 'Faculty of Agricultural Sciences', 'Crop and Environmental Protection\n'),
(22, 'Faculty of Agricultural Sciences', '\nAnimal Nutrition and Bio-Technology'),
(23, 'Faculty of Agricultural Sciences', 'Animal Production and Health'),
(26, 'Faculty of Environment Sciences', 'Urban and Regional Planning'),
(25, 'Faculty of Environment Sciences', 'Fine and Applied Arts'),
(24, 'Faculty of Environment Sciences', 'Architecture'),
(27, 'Faculty of Engineering and Technology', 'Chemical Engineering\n'),
(28, 'Faculty of Engineering and Technology', 'Civil Engineering\n'),
(29, 'Faculty of Engineering and Technology', 'Computer Science and Engineering\n'),
(30, 'Faculty of Engineering and Technology', '\nElectronic and Electrical Engineering'),
(31, 'Faculty of Engineering and Technology', 'Food Science and Engineering\n'),
(32, 'Faculty of Engineering and Technology', 'Mechanical Engineering'),
(33, 'Faculty of Engineering and Technology', 'Agricultural Engineering'),
(34, 'Faculty of Pure and Applied Science', 'Pure and Applied Biology'),
(35, 'Faculty of Pure and Applied Science', 'Pure and Applied Chemistry'),
(36, 'Faculty of Pure and Applied Science', 'Pure and Applied Mathematics'),
(37, 'Faculty of Pure and Applied Science', 'Pure and Applied Physics'),
(38, 'Faculty of Pure and Applied Science', 'General Studies'),
(39, 'Faculty of Pure and Applied Science', 'Earth Science'),
(40, 'Faculty of Pure and Applied Science', 'Science Laboratory Technology'),
(41, 'Faculty of Management Sciences', 'Management and Accounting'),
(42, 'Faculty of Management Sciences', 'Transport Management');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `faculty_id` int(11) NOT NULL,
  `faculty_name` varchar(222) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `faculty_name`) VALUES
(1, 'Faculty of Basic Medical Sciences'),
(2, 'Faculty of Clinical Sciences'),
(3, 'Faculty of Agricultural Sciences'),
(4, 'Faculty of Environment Sciences'),
(5, 'Faculty of Engineering and Technology'),
(6, 'Faculty of Pure and Applied Science'),
(7, 'Faculty of Management Sciences');

-- --------------------------------------------------------

--
-- Table structure for table `nominees`
--

CREATE TABLE `nominees` (
  `id` int(11) NOT NULL,
  `org` varchar(60) NOT NULL,
  `pos` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `course` varchar(60) NOT NULL,
  `year` varchar(4) NOT NULL,
  `stud_id` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nominees`
--

INSERT INTO `nominees` (`id`, `org`, `pos`, `name`, `course`, `year`, `stud_id`) VALUES
(14, 'LAUTECH', 'President', 'Modupeola Temiloluwa', 'Pure and Applied Mathematics', '500L', '122438'),
(15, 'LAUTECH', 'President', 'Oluwasusi Victor Ayodeji', 'Pure and Applied Mathematics', '500L', '121360'),
(16, 'LAUTECH', 'Vice-President', 'Yusuf Damilola', 'Computer Science and Engineering', '500L', '121192'),
(17, 'LAUTECH', 'Vice-President', 'Olajide Francisca', 'Pure and Applied Mathematics', '500L', '123405');

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE `organization` (
  `id` int(11) NOT NULL,
  `org` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`id`, `org`) VALUES
(55, 'Pure and Applied Mathematics'),
(56, 'Faculty of Pure and Applied Science'),
(58, 'LAUTECH');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `id` int(11) NOT NULL,
  `org` varchar(60) NOT NULL,
  `pos` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`id`, `org`, `pos`) VALUES
(20, 'LAUTECH', 'President'),
(21, 'LAUTECH', 'Vice-President'),
(22, 'LAUTECH', 'General Secretary'),
(23, 'LAUTECH', 'Financial Secretary'),
(24, 'LAUTECH', 'Sport Director'),
(25, 'Faculty of Pure and Applied Science', 'President');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `department` varchar(222) NOT NULL,
  `faculty` varchar(222) NOT NULL,
  `institution` varchar(222) NOT NULL,
  `year` varchar(4) NOT NULL,
  `stud_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`id`, `name`, `department`, `faculty`, `institution`, `year`, `stud_id`) VALUES
(10, 'Badmus Yetunde', 'Computer Science and Engineering', 'Faculty of Engineering and Technology', 'LAUTECH', '500L', '121124'),
(11, 'Silver', 'Pure and Applied Mathematics', 'Faculty of Pure and Applied Science', 'LAUTECH', '400L', '123454');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `org` varchar(60) NOT NULL,
  `pos` varchar(60) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `voters_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `org`, `pos`, `candidate_id`, `voters_id`) VALUES
(18, 'Faculty of Pure and Applied Science', 'President', 0, 7),
(19, 'LAUTECH', 'President', 15, 10),
(20, 'LAUTECH', 'President', 14, 11);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `nominees`
--
ALTER TABLE `nominees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `nominees`
--
ALTER TABLE `nominees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
